ORIGIN BAZAR - ANDROID SIGNING KEY  (KEEP PRIVATE - NEVER UPLOAD PUBLICLY)

originbazar-upload.jks   The app's signing key. Every update must be signed with it.
keystore-base64.txt      Same key as text -> GitHub secret OB_KEYSTORE_BASE64
passwords.txt            Values for GitHub secrets OB_KEYSTORE_PASSWORD, OB_KEY_ALIAS, OB_KEY_PASSWORD
assetlinks.json          Upload to https://originbazar.store/.well-known/assetlinks.json (optional,
                         makes originbazar.store links open the app directly)

Key alias: originbazar
SHA-256 fingerprint: 56:7D:CF:BD:1B:D4:31:FF:50:7B:86:F6:4B:CD:F3:9C:4F:5A:1E:91:61:4F:40:9E:77:66:13:32:99:7B:A4:A4

Back up this folder in two safe places. If it is lost, existing users cannot receive updates.
If you publish on Google Play with "Play App Signing", this becomes your upload key.
